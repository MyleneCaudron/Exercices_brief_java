import java.util.ArrayList;
import java.util.List;

//Créer une classe Etudiant contenant différentes informations en dur (dont plusieurs notes)
//Permettre à l’étudiant de calculer la moyenne des notes
//Permettre à l’étudiant d’afficher ses initiales
//Permettre à l’étudiant d’afficher son trigramme (1ère lettre du prénom, 1ère lettre du nom, dernière lettre du
//nom)

public class Etudiant {

    List<Etudiant> etudiant = new ArrayList<>();
    
	private double note1 = 15;
	private double note2 = 10;
	private double note3 = 13;
	private double note4 = 14;
	private String prenom;
	private String nom;

	public Etudiant(double note1, double note2, double note3, double note4, String prenom, String nom) {
		super();
		this.note1 = note1;
		this.note2 = note2;
		this.note3 = note3;
		this.note4 = note4;
		this.prenom = prenom;
		this.nom = nom;
	}

	public double moyenne() {

		return (note1 + note2 + note3 + note4)/4;
	}

	public StringBuilder trigramme() {

		char FirstLetterPrenom = prenom.charAt(0);
		char FirstLetterNom = nom.charAt(0);
		int n = nom.length();
		char LastLetterNom = nom.charAt(n);
		
		StringBuilder tri = new StringBuilder();
		tri.append(FirstLetterPrenom).append(FirstLetterNom).append(LastLetterNom);
		return tri;		
		
	}

	public double getNote1() {
		return note1;
	}

	public void setNote1(double note1) {
		this.note1 = note1;
	}

	public double getNote2() {
		return note2;
	}

	public void setNote2(double note2) {
		this.note2 = note2;
	}

	public double getNote3() {
		return note3;
	}

	public void setNote3(double note3) {
		this.note3 = note3;
	}

	public double getNote4() {
		return note4;
	}

	public void setNote4(double note4) {
		this.note4 = note4;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

}
