//Créer une classe voiture.
//Permettre de créer des voitures avec plusieurs types de constructeurs 

public class Voiture {

	private String marque;
	private double vitesse;
	private int puissance;

//constructeur par défaut

	public Voiture() {

		this.marque = marque;
		this.vitesse = vitesse;
		this.puissance = puissance;

	}

//constructeur par parametre

	public Voiture(String marque, double vitesse, int puissance) {

		this.marque = marque;
		this.vitesse = vitesse;
		this.puissance = puissance;
	}

//constructeur par recopie

	Voiture(Voiture v) {

		marque = v.marque;
		vitesse = v.vitesse;
		puissance = v.puissance;
	}

}
