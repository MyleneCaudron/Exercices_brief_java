//Créer une classe permettant de faire des opérations mathématiques 

public class Maths {

	private float a;
	private float b;

	public Maths(float a, float b) {
		super();
		this.a = a;
		this.b = b;

	}

	public float addition(float a, float b) {

		return a + b;

	}

	public float getA() {
		return a;
	}

	public void setA(float a) {
		this.a = a;
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		this.b = b;
	}

}
