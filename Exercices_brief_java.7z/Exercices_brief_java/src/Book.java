import java.util.ArrayList;
import java.util.List;


/**
 * @author Apprenant
 *
 */
public class Book {

    List<Book> monLivre = new ArrayList<>();
    
	private String	titre;
	private String	prenom_auteur;
	private String	nom_auteur;         
	private String	cat;		
	private String	isbn;	
	private String code;


	public Book() {
		
        this.titre = titre; 
		this.nom_auteur = nom_auteur; 
		this.prenom_auteur = prenom_auteur; 
		this.cat = cat; 
		this.isbn = isbn; 
	}

	public StringBuilder Code() {
		char FirstLetterPrenom = prenom_auteur.charAt(0);
		char FirstLetterNom = nom_auteur.charAt(0);
		char FirstLetterCat = cat.charAt(0);
		int n = isbn.length();
		char LastLetter = isbn.charAt(n-1);
		char SecondToLastLetter = isbn.charAt(n-2);
		StringBuilder code = new StringBuilder();
		code.append(FirstLetterPrenom).append(FirstLetterNom).append(FirstLetterCat).append(LastLetter).append(SecondToLastLetter);
		return code;
		
	}

	
	public String toString() {
	    return "titre : " + titre + " ,prenom : "+ prenom_auteur + " ,nom : " +
	nom_auteur + " ,catégorie : " + cat + " ,ISBN : " + isbn + " ,code : " + code;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getPrenom_auteur() {
		return prenom_auteur;
	}

	public void setPrenom_auteur(String prenom_auteur) {
		this.prenom_auteur = prenom_auteur;
	}

	public String getNom_auteur() {
		return nom_auteur;
	}

	public void setNom_auteur(String nom_auteur) {
		this.nom_auteur = nom_auteur;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

}

