//Compter le nombre de chaque lettre d’une chaîne de caractères saisis par l’utilisateur 

import java.util.Scanner;

public class Count {

	public static void main(String[] args) {
		
		String str;
		int count=0;
		
		Scanner scan = new Scanner(System.in);
		System.out.println("entrez une phrase :");
		
		str = scan.nextLine();
          
        for(int i = 0; i < str.length(); i++) {  
        		count++;
        }  
        System.out.println("Nombre total de caractères est: " + count);  

	}

}
