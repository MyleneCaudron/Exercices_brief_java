//Dans une chaîne de caractères, remplacer un caractère sur 2 par * 

import java.util.Scanner;

public class RemplacerChar {

	public static void main(String[] args) {

		String str;
		
		Scanner scan = new Scanner(System.in);
		System.out.println("entrez une phrase :");
		
		str = scan.nextLine();
		char[] ch = new char[str.length()];
		
		StringBuilder s = new StringBuilder();
		
        for (int i = 0; i < str.length(); i++) {
            ch[i] = str.charAt(i);
        	if (i%2==0) {
        		s.append(ch[i]);
        		
        	}
        	if(i%2==1) {
        		s.append("*");
        	}
        }
        
        System.out.println(s);
    }
}