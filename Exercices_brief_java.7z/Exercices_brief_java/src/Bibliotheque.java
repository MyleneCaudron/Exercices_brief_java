//Créer une classe Livre avec pour comportement d’afficher les informations le concernant.
//Afficher également le code du livre construit à partir des 2ères lettres des nom et prénom de l’auteur, la 1ère
//lettre de la catégorie et les 2 dernières lettres de l’ISBN.
//La classe Bibliothèque devra afficher ses informations dans la console.


public class Bibliotheque {

	public static void main(String[] args) {
		
		Book monLivre = new Book();
		monLivre.setTitre("Le Fléau");
		monLivre.setCat("Roman");
		monLivre.setIsbn("9780307743688");
		monLivre .setNom_auteur("King");
		monLivre.setPrenom_auteur("Stephen");
		monLivre.Code();
		
		System.out.println(monLivre);
		System.out.println(monLivre.Code());
		

	}

}
