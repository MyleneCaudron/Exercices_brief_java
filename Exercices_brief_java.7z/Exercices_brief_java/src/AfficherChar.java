//Afficher une chaîne de caractères saisies par l’utilisateur en minuscules puis en majuscules 

import java.util.Scanner;

public class AfficherChar {

	public static void main(String[] args) {
		
		String str;
		
		Scanner scan = new Scanner(System.in);
		System.out.println("entrez une phrase :");
		
		str = scan.nextLine();
 
        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());        
	}
}
